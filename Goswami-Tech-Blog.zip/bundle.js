
document.getElementById("root").innerHTML = `
  <h1 style='text-align:center;color:#4F46E5;'>Goswami Tech Blog</h1>
  <p style='text-align:center;'>यहाँ आपको नवीनतम टेक्नोलॉजी की जानकारी मिलेगी।</p>
`;
